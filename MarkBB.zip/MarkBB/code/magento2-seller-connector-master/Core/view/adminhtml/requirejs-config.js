var config = {
    paths: {
        'mirakl_seller_core/template': 'MiraklSeller_Core/templates'
    },
    config: {
        mixins: {
            'Magento_Ui/js/form/components/tab_group': {
                'MiraklSeller_Core/js/form/components/tab_group': true
            }
        }
    }
};