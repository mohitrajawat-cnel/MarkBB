<?php
namespace MiraklSeller\Core\Ui\Component\DataProvider;

use Magento\Framework\View\Element\UiComponent\DataProvider\DataProvider;

class Listing extends DataProvider
{}