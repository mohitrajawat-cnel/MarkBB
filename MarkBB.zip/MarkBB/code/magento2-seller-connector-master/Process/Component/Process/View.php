<?php
namespace MiraklSeller\Process\Component\Process;

use Magento\Ui\Component\Form;

class View extends Form
{
    const NAME = 'mirakl_process_view';
}
