var config = {
    config: {
        mixins: {
            'Magento_Ui/js/lib/validation/validator': {
                'MiraklSeller_Api/js/validator-mixin': true
            }
        }
    }
};