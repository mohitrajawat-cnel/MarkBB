<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
require 'vendor/autoload.php';
$reader = \PhpOffice\PhpSpreadsheet\IOFactory::createReader('Csv');

// If the files uses a delimiter other than a comma (e.g. a tab), then tell the reader
// $reader->setDelimiter("\t");
// If the files uses an encoding other than UTF-8 or ASCII, then tell the reader
// $reader->setInputEncoding('UTF-16LE');

$objPHPExcel = $reader->load('/home/u688797554/domains/303mb.com/public_html/MarkBB/test/file.csv');
$objWriter = \PhpOffice\PhpSpreadsheet\IOFactory::createWriter($objPHPExcel, 'Xlsx');
$objWriter->save('excel_file.xlsx');